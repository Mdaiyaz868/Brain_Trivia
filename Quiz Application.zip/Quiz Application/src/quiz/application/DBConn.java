package quiz.application;

import java.sql.*;

public class DBConn {
    public Connection con;
    public PreparedStatement pstmt;
    public Statement stmt;
    public ResultSet rst;   
    DBConn(){
        try{
           // Class.forName("com.mysql.jdbc.Driver");
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/quizdb","root","A!y@Z887");
            System.out.println("Connection Established Successfully");
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        DBConn db = new DBConn();
    }
    
}
